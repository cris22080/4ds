public class JavaInputException extends RuntimeException {
    public JavaInputException() {
        super("Il tuo input è sbagliato");
    }
}
